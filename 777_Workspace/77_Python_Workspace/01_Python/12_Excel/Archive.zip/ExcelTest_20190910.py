import pandas as pd
import numpy as np
import os
from pathlib import Path

def function(x):
    y = x + 2
    return y

print("File      Path:", Path(__file__).absolute())
print("Directory Path:", Path().absolute()) 

csvFile = pd.read_csv('test_csv_common.csv', delimiter = ',')
sourcePath = csvFile.SourcePath

for source in sourcePath:
    print(source)
